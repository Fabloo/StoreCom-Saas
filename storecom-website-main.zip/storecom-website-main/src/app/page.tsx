// This page is intentionally left blank. 
// The main dashboard has been moved to /dashboard.
// This root page can be used for a future landing page.
export default function RootPage() {
  return null;
}
